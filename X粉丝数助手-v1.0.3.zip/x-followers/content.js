(() => {
  const channel = 'x-followers-helper-v1';
  const cache = new Map();
  const selector = '[data-testid="User-Name"], [data-testid="UserName"], [data-testid="UserCell"]';
  let scheduled = false;
  let bridgeReady = false;
  let responses = 0;
  const compact = new Intl.NumberFormat('zh-CN', { notation: 'compact', maximumFractionDigits: 1 });
  function originalText(element) {
    const copy = element.cloneNode(true);
    copy.querySelectorAll('[data-xfh-badge]').forEach(badge => badge.remove());
    return copy.textContent.replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, '').trim();
  }
  function nickname(container, user) {
    for (const link of container.querySelectorAll('a[href]')) {
      const url = new URL(link.getAttribute('href'), location.href);
      const text = originalText(link);
      if (url.origin === location.origin && url.pathname.replace(/\/$/, '').toLowerCase() === '/' + user.handle &&
          text && !text.startsWith('@')) return link;
    }
    return user.link;
  }
  function identity(container) {
    for (const link of container.querySelectorAll('a[href]')) {
      try {
        const url = new URL(link.getAttribute('href'), location.href);
        if (url.origin !== location.origin) continue;
        const match = url.pathname.match(/^\/([a-zA-Z0-9_]{1,15})\/?$/);
        if (match && originalText(link).toLowerCase() === '@' + match[1].toLowerCase()) {
          return { handle: match[1].toLowerCase(), link };
        }
      } catch {}
    }
    return null;
  }
  function render() {
    scheduled = false;
    document.querySelectorAll(selector).forEach(container => {
      // UserCell may contain a more precise username container.
      if (container.matches('[data-testid="UserCell"]') && container.querySelector('[data-testid="User-Name"], [data-testid="UserName"]')) return;
      const user = identity(container);
      const count = user && cache.get(user.handle);
      let badge = container.querySelector('[data-xfh-badge]');
      if (count === undefined || !user) { badge?.remove(); return; }
      if (!badge) {
        badge = document.createElement('span');
        badge.setAttribute('data-xfh-badge', '');
      }
      const label = `${compact.format(count)} 粉丝`;
      const title = `@${user.handle}：${count.toLocaleString('zh-CN')} 位粉丝（页面已加载数据）`;
      if (badge.textContent !== label) badge.textContent = label;
      if (badge.title !== title) {
        badge.title = title;
        badge.setAttribute('aria-label', title);
      }
      badge.toggleAttribute('data-xfh-popular', count > 10000);
      const name = nickname(container, user);
      container.querySelectorAll('[data-xfh-name-row]').forEach(row => {
        if (row !== name) row.removeAttribute('data-xfh-name-row');
      });
      name.setAttribute('data-xfh-name-row', '');
      if (badge.parentElement !== name || name.lastChild !== badge) name.append(badge);
    });
  }
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(render, 120);
  }
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin ||
        event.data?.channel !== channel) return;
    if (event.data.type === 'status' && Number.isSafeInteger(event.data.responses) && event.data.responses >= 0) {
      bridgeReady = true;
      responses = event.data.responses;
      return;
    }
    if (event.data.type !== 'users' || !Array.isArray(event.data.users)) return;
    bridgeReady = true;
    for (const user of event.data.users.slice(0, 200)) {
      if (!user || typeof user.handle !== 'string' || !/^[a-z0-9_]{1,15}$/.test(user.handle) ||
          !Number.isSafeInteger(user.count) || user.count < 0) continue;
      cache.delete(user.handle);
      cache.set(user.handle, user.count);
    }
    while (cache.size > 10000) cache.delete(cache.keys().next().value);
    schedule();
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (message?.type !== 'xfh-status') return;
    reply({ version: chrome.runtime.getManifest().version, bridgeReady, responses,
      users: cache.size, containers: document.querySelectorAll(selector).length,
      badges: document.querySelectorAll('[data-xfh-badge]').length });
  });
  new MutationObserver(schedule).observe(document, {
    childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['href']
  });
  window.postMessage({ channel, type: 'ready' }, location.origin);
  // Retry the handshake at document readiness in case world startup ordering differs.
  document.addEventListener('DOMContentLoaded', () => {
    window.postMessage({ channel, type: 'ready' }, location.origin);
    schedule();
  }, { once: true });
})();
