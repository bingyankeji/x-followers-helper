(() => {
  // Walk nested GraphQL results without depending on operation names or IDs.
  function extract(root) {
    const users = new Map();
    const stack = [root];
    const seen = new WeakSet();
    while (stack.length) {
      const node = stack.pop();
      if (!node || typeof node !== 'object' || seen.has(node)) continue;
      seen.add(node);
      const handle = node.core?.screen_name ?? node.legacy?.screen_name ?? node.screen_name;
      const count = node.relationship_counts?.followers ?? node.legacy?.followers_count ?? node.followers_count;
      if (typeof handle === 'string' && /^[a-zA-Z0-9_]{1,15}$/.test(handle) &&
          Number.isSafeInteger(count) && count >= 0) {
        // The nested legacy object can repeat the same handle. Keep its parent's modern count.
        const key = handle.toLowerCase();
        if (!users.has(key)) users.set(key, { handle: key, count });
      }
      for (const value of Object.values(node)) {
        if (value && typeof value === 'object') stack.push(value);
      }
    }
    return [...users.values()];
  }
  globalThis.__XFollowersExtract = extract;
})();
