(() => {
  const extract = globalThis.__XFollowersExtract;
  const cache = new Map();
  const channel = 'x-followers-helper-v1';
  let responses = 0;
  function status() {
    window.postMessage({ channel, type: 'status', responses }, location.origin);
  }
  function send(users) {
    for (let i = 0; i < users.length; i += 200) {
      window.postMessage({ channel, type: 'users', users: users.slice(i, i + 200) }, location.origin);
    }
  }
  function consume(data) {
    try {
      const changed = extract(data).filter(user => cache.get(user.handle)?.count !== user.count);
      for (const user of changed) {
        cache.delete(user.handle);
        cache.set(user.handle, user);
      }
      while (cache.size > 10000) cache.delete(cache.keys().next().value);
      send(changed);
    } catch { /* Observation must never break the host page. */ }
  }
  function received(data) {
    responses++;
    consume(data);
    status();
  }
  function relevant(raw) {
    try {
      const url = new URL(raw, location.href);
      return /(^|\.)(x\.com|twitter\.com)$/.test(url.hostname) &&
        /\/(graphql|api|1\.1|2)\//.test(url.pathname);
    } catch { return false; }
  }
  const originalFetch = window.fetch;
  window.fetch = function (...args) {
    const promise = Reflect.apply(originalFetch, this, args);
    // Return the original promise; parsing runs independently on a clone.
    promise.then(response => {
      try {
        if (relevant(response.url || (args[0] instanceof Request ? args[0].url : args[0]))) {
          response.clone().json().then(received).catch(() => {});
        }
      } catch {}
    }, () => {});
    return promise;
  };
  const originalOpen = XMLHttpRequest.prototype.open;
  const urls = new WeakMap();
  const installed = new WeakSet();
  XMLHttpRequest.prototype.open = function (...args) {
    const result = Reflect.apply(originalOpen, this, args);
    urls.set(this, args[1]);
    if (!installed.has(this)) {
      installed.add(this);
      this.addEventListener('load', function () {
        if (!relevant(this.responseURL || urls.get(this))) return;
        try {
          if (this.responseType === 'json') received(this.response);
          else if (!this.responseType || this.responseType === 'text') received(JSON.parse(this.responseText));
        } catch {}
      });
    }
    return result;
  };
  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== location.origin ||
        event.data?.channel !== channel || event.data?.type !== 'ready') return;
    consume(window.__INITIAL_STATE__);
    send([...cache.values()]);
    status();
  });
  document.addEventListener('DOMContentLoaded', () => consume(window.__INITIAL_STATE__), { once: true });
})();
