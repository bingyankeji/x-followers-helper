(async () => {
  const output = document.getElementById('status');
  const help = document.getElementById('help');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No tab');
    const state = await chrome.tabs.sendMessage(tab.id, { type: 'xfh-status' });
    output.textContent = `版本：${state.version}\n页面脚本：已运行\n数据监听：${state.bridgeReady ? '已连接' : '未连接'}\n已读取响应：${state.responses}\n已取得粉丝数的账号：${state.users}\n用户名区域：${state.containers}\n已显示标签：${state.badges}`;
    help.textContent = state.badges > 0 ? '标签已添加，鼠标停留可查看完整数量。' :
      !state.bridgeReady ? '请重新加载扩展，再刷新 X 页面。' :
      !state.responses ? '请刷新 X 并滚动加载几条帖子，然后重新打开此窗口。' :
      !state.users ? '已收到响应，但未找到粉丝字段。请把此窗口截图发来继续排查。' :
      '已取得数据，但尚未匹配到页面用户名。请把此窗口和 X 页面截图发来继续排查。';
  } catch {
    output.textContent = `扩展版本：${chrome.runtime.getManifest().version}\n当前标签页未连接到插件。`;
    help.textContent = '请切到 x.com 页面并刷新。若刚更新插件，请先在扩展管理页点击重新加载，再刷新 X。';
  }
})();
